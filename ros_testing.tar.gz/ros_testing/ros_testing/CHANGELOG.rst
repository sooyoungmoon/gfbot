^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_testing
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2022-01-13)
------------------

0.3.0 (2021-03-19)
------------------
* Use rostest CMake target as output file basename. (`#9 <https://github.com/ros2/ros_testing/issues/9>`_)
* Contributors: Michel Hidalgo

0.2.1 (2020-04-30)
------------------

0.2.0 (2019-09-26)
------------------

0.1.0 (2019-05-20)
------------------
* Add ros_testing metapackage and ros2test CLI package (`#1 <https://github.com/ros2/ros_testing/issues/1>`_)
* Contributors: Michel Hidalgo
