#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <libserial/SerialStream.h>
#include <libserial/SerialPort.h>
#include <iostream>
#include <string>

using namespace std;
using namespace LibSerial;

const int BUFFER_SIZE = 256;

class SerialNode : public rclcpp::Node {
public:
  SerialNode() : Node("serial_node") {
    // Initialize the serial stream
    my_serial_port.Open("/dev/ttyACM0");
    my_serial_port.SetBaudRate(BaudRate::BAUD_9600);
    my_serial_port.SetCharacterSize(CharacterSize::CHAR_SIZE_8);
    my_serial_port.SetParity(Parity::PARITY_NONE);
    my_serial_port.SetStopBits(StopBits::STOP_BITS_1);
    my_serial_port.SetFlowControl(FlowControl::FLOW_CONTROL_NONE);


    if (!my_serial_port.IsOpen()) {
      RCLCPP_ERROR(this->get_logger(), "Error: Could not open serial port.");
      return;
    }

    // Create a publisher to publish received data
    publisher_ = this->create_publisher<std_msgs::msg::String>("serial_data", 10);

    // Create a timer to periodically read data from the serial port
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(1000),
      std::bind(&SerialNode::read_serial_data, this)
    );
  }

private:
  void read_serial_data() {
      // write string data to serial port
    std::string write_data = "0.2,0";
    
    assert(write_data.size() < BUFFER_SIZE);

    for (size_t i = 0; i < write_data.size(); i++) {
      output_buffer[i] = write_data[i];    }

    output_buffer[write_data.size()] = '\n';
    my_serial_port.Write(output_buffer);

    RCLCPP_INFO(this->get_logger(), "Sent: %s", write_data.c_str());
    
    //my_serial_port.Write(write_data);
    //RCLCPP_INFO(this->get_logger(), "Sent: %s", write_data.c_str());

    //cout << "Reading data from serial port" << endl;
  if (my_serial_port.IsDataAvailable()) {
    std::string read_data;
    my_serial_port.ReadLine(read_data);
    RCLCPP_INFO(this->get_logger(), "Received: %s", read_data.c_str());
  } else {
    ;//RCLCPP_WARN(this->get_logger(), "No data available to read.");
  }  

  }

  char output_buffer[BUFFER_SIZE];
  SerialPort my_serial_port;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<SerialNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  
  return 0;
}
