******************************************
Changelog for package jarabot_cartographer
******************************************

1.0.0 (2023-08-09)
------------------
* ROS2 Humble supported
