def main():

    # 구구단을 출력합니다.

    for i in range(1, 10):

        for j in range(1, 10):

            # 구구단 계산 결과를 출력합니다.

            print(f'{j}x{i}={j*i}', end='\t')  # 각 항목을 탭으로 구분하여 출력합니다.

        print()  # 다음 줄로 넘어갑니다.

if __name__ == '__main__':

    main()