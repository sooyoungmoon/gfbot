# Minimal service server cookbook recipes

This package contains a few strategies to create service servers.
The `service` recipe shows how to define a service server in an analog way to ROS 1 and rospy
The `service_member_function` recipe creates a MinimalService class that processes the incoming requests
