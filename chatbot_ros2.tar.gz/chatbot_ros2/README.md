# chatbot_ros2
## Introduction
This repository is for sharing knowledge to -
1) create a chatbot using ([OpenAI API](https://openai.com/index/openai-api/))
2) make the chatbot read/write data from/to ROS2 nodes
3) apply the techniques above to robotics applications

## Where to start?

