# localization_kf
a sample project for localization of mobile robots using Kalman filter algorithm (based on ROS2)
