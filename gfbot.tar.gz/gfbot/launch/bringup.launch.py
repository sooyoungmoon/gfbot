import launch
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import IncludeLaunchDescription
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    return LaunchDescription([

        IncludeLaunchDescription(          
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('gfbot'), 
                    'launch',
                    'include', 
                    'serial_driver.launch.py'
                    ])
                    ])
        ),
        Node(
            package='gfbot',
            executable='gf_controller',
            name='gf_controller',
           
            #parameters=[{'param_name': 'param_value'}]
        ),
        # Add more nodes here if needed
        Node(
            package='gfbot',
            executable='gf_driver',
            name='gf_driver',           
            #parameters=[{'param_name': 'param_value'}]
        )
    ])