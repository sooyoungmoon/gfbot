#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/u_int8_multi_array.hpp"


class GfDriver : public rclcpp::Node
{
public:
    GfDriver() : Node("gf_controller")
    {
        RCLCPP_INFO(this->get_logger(), "GfDriver node has been started.");
        timer_ = this->create_wall_timer(
        std::chrono::seconds(1),
        std::bind(&GfDriver::timer_callback, this));

        serial_pub = this->create_publisher<std_msgs::msg::UInt8MultiArray>("/serial_write", 10);
    }

private:
    void timer_callback()
    {
        RCLCPP_INFO(this->get_logger(), "Timer callback triggered.");
        auto serial_msg = std_msgs::msg::UInt8MultiArray();
        std::string str = std::to_string(linear_velocity) + "," + std::to_string(angular_velocity);
        serial_msg.data.reserve(str.size());

        for (auto c : str)
        {
            serial_msg.data.push_back(c);
            RCLCPP_INFO(this->get_logger(), "Character: %c", c);
        }

        serial_pub->publish(serial_msg);
    }

    rclcpp::TimerBase::SharedPtr timer_;

private:
    float linear_velocity = 0.2;
    float angular_velocity = 0.1;
    rclcpp::Publisher<std_msgs::msg::UInt8MultiArray>::SharedPtr serial_pub;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<GfDriver>());
    rclcpp::shutdown();
    return 0;
}