#include "rclcpp/rclcpp.hpp"

class GfController : public rclcpp::Node
{
public:
    GfController() : Node("gf_controller")
    {
        RCLCPP_INFO(this->get_logger(), "GfController node has been started.");
    }
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<GfController>());
    rclcpp::shutdown();
    return 0;
}